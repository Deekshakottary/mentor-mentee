
This is a DATABASE MANAGEMENT  system for Mentor-mentee where mentors can do crud operation and mentees can view their updated marks  and many 
